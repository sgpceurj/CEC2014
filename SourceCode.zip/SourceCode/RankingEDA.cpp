/*
 *  RankingEDA.cpp
 *  RankingEDAsCEC
 *
 *  Created by Josu Ceberio Uribe on 9/15/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

#include "RankingEDA.h"
#include "MallowsModel.h"
#include "Cayley.h"
#include "GeneralizedMallowsModel.h"

/*
 * The constructor.
 */
RankingEDA::RankingEDA(PBP * problem, int problem_size, long int max_evaluations, char* model_type, char* metric_type)
{
    //1. standard initializations
    m_problem=problem;
    m_problem_size=problem_size;
    m_max_evaluations=max_evaluations;
    m_evaluations=0;
    m_convergence_evaluations=0;
    m_best= new CIndividual(problem_size);
    m_best->SetValue(MIN_LONG_INTEGER);
    m_pop_size=m_problem_size*10;
    m_sel_size=m_problem_size;
    m_offspring_size= m_pop_size-1;
    memcpy(m_metric_type,metric_type,sizeof(char)*10);
    memcpy(m_model_type,model_type,sizeof(char)*10);
    
    //2. initialize the population
    m_population= new CPopulation(m_pop_size, m_offspring_size,m_problem_size);
    int * genes= new int[m_problem_size];
    for(int i=0;i<m_pop_size;i++)
	{
		//Create random individual
		GenerateRandomPermutation(genes,m_problem_size);

        m_population->SetToPopulation(genes, i,m_problem->Evaluate(genes));
        m_evaluations++;
    }
    
    m_population->SortPopulation(0);

    delete [] genes;
    
    
    //3. Build model structures
    if (((string)model_type)=="M"){
        m_model=new CMallowsModel(m_problem_size, m_sel_size, metric_type);
    }
    else if (((string)model_type)=="GM")
    {
        m_model=new CGeneralizedMallowsModel(m_problem_size, m_sel_size, metric_type);
    }
 
}

/*
 * The destructor. It frees the memory allocated..
 */
RankingEDA::~RankingEDA()
{
    delete m_best;
    delete m_population;
    delete m_model;
}


/*
 * Running function
 */
int RankingEDA::Run(){
    
    //variable initializations.
    int i;
    long int newScore;
    int * genes= new int[m_problem_size];
    int iterations=1;
    //EDA iteration. Stopping criterion is the maximum number of evaluations performed
    while (m_evaluations<m_max_evaluations){

        //learn model
        m_model->Learn(m_population, m_sel_size);

        //sample the model.
        for (i=0;i< m_offspring_size && m_evaluations<m_max_evaluations;i++){
            m_model->Sample(genes);
           
            if (((string)m_metric_type)=="k")
                m_population->AddToPopulation(genes, i, m_problem->EvaluateInv(genes));
            else
                m_population->AddToPopulation(genes, i, m_problem->Evaluate(genes));
            m_evaluations++;
        }
        
        //update the model.
        m_population->SortPopulation(1);

        //update indicators
       newScore=m_population->m_individuals[0]->Value();

        if (newScore>m_best->Value())
        {
            
            m_best->SetGenes(m_population->m_individuals[0]->Genes());
            m_best->SetValue(newScore);
            m_convergence_evaluations=m_evaluations;
/*            if (((string)m_model_type)=="M")
                cout<<""<<m_population->m_individuals[0]->Value()<<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<"  Theta. "<<((CMallowsModel*)m_model)->m_distance_model->m_theta_parameter<<endl;
            else
                cout<<""<<m_population->m_individuals[0]->Value()<<" , "<<m_evaluations<<" , "<<m_max_evaluations-m_evaluations<<"  Thetas. "<<((CGeneralizedMallowsModel*)m_model)->m_distance_model->m_theta_parameters[0]<<endl;
  */
      }
        iterations++;
    }
    delete [] genes;
    
    return 0;
}

/*
 * Returns the number of performed evaluations.
 */
int RankingEDA::GetPerformedEvaluations(){
    return m_convergence_evaluations;
}

/*
 * Returns the fitness of the best solution obtained.
 */
long int RankingEDA::GetBestSolutionFitness(){
    return m_best->Value();
}

/*
 * Returns the best solution obtained.
 */
CIndividual * RankingEDA::GetBestSolution(){
    return m_best;
}


/*
 * This method applies a swap of the given i,j positions in the array.
 */
void RankingEDA::Swap(int * array, int i, int j)
{
	int aux=array[i];
	array[i]=array[j];
	array[j]=aux;
}
