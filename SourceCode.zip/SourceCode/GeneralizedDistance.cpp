//
//  GeneralizedDistances.cpp
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/20/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "GeneralizedDistance.h"
/*
 * The constructor.
 */
GeneralizedDistance_Model::GeneralizedDistance_Model()
{
	
}

/*
 * The destructor.
 */
GeneralizedDistance_Model::~GeneralizedDistance_Model()
{
    
}
