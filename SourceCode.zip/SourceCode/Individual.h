//
//  Individual.h
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#ifndef _INDIVIDUAL_
#define _INDIVIDUAL_

#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <limits.h>
#include <iostream>
#include "Variables.h"
using namespace std;
using std::istream;
using std::ostream;

class CIndividual
{
public:

	// The constructor. The constructed individual has
	// all zeroes as its genes.
	CIndividual(int length);

	// The destructor. It frees the memory allocated at
	// the construction of the individual.
	virtual ~CIndividual();

	// It returns an array with the genes of the individual.
	int * Genes();

	// It returns the value of the individual.
	long int Value();
	
	void SetValue(long int value);
	void SetGenes(int * genes);
		
	// Prints in standard output 'length' integer elements of a given array.
	void PrintGenes();
	
	// Clone the individual.
	CIndividual * Clone();

	// Input and output of an individual: its value and genes.
	friend ostream & operator<<(ostream & os,CIndividual * & individual);
	friend istream & operator>>(istream & is,CIndividual * & individual);

       
private:

	// The variable storing the individual's value. 
	long int m_value;

	 // The genes of the individual.
	int * m_genes;
	
	//The size of the individual
	int m_size;
	
	//Auxiliray array.
	//int * aux_genes;

};

#endif
