//
//  Individual.cc
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "Individual.h"
#include "Tools.h"

// The object storing the values of all the individuals
// that have been created during the execution of the
// program. 

CIndividual::CIndividual(int length)
{
	m_size = length;
	m_genes = new int[m_size];
	//aux_genes=new int[m_size];
    m_value=MIN_LONG_INTEGER;
}

CIndividual::~CIndividual()
{
	delete [] m_genes;
	//delete [] aux_genes;
	m_genes=NULL;
}

long int CIndividual::Value()
{
	return m_value;
}


int * CIndividual::Genes()
{
	return m_genes;
}

ostream & operator<<(ostream & os,CIndividual * & individual)
{
	//os << individual->Value() << ",";

        os << individual->m_genes[0];
	for(int i=1;i<individual->m_size;i++)
	//	os << "," << individual->m_genes[i];
   os << " " << individual->m_genes[i];

//    os << ".";

	return os;
}

istream & operator>>(istream & is,CIndividual * & individual)
{
  char k; //to avoid intermediate characters such as ,.

  is >> individual->m_value;
  is >> individual->m_genes[0];
  for(int i=1;i<individual->m_size;i++)
    is >> k >> individual->m_genes[i];
  is >> k;

  return is;
}

void CIndividual::SetValue(long int value)
{
	m_value=value;
}

void CIndividual::SetGenes(int * genes)
{
	memcpy(m_genes, genes, sizeof(int)*m_size);
//    for (int i=0;i<m_size;i++) m_genes[i]=genes[i];
	m_value=MIN_LONG_INTEGER;
}

/*
 * Prints in the standard output genes.
 */
void CIndividual::PrintGenes()
{
	for (int i=0;i<m_size;i++){
		cout<<m_genes[i]<<" ";
	}
	cout<<" "<<endl;
}

CIndividual * CIndividual::Clone()
{
	CIndividual * ind = new CIndividual(m_size);
	ind->SetGenes(m_genes);
	ind->SetValue(m_value);
	return ind;
}



